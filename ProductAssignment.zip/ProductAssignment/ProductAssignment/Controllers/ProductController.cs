﻿using Microsoft.AspNetCore.Mvc;
using ProductAssignment.Models;
using System.Linq;

namespace ProductAssignment.Controllers
{
    public class ProductController : Controller
    {

        public IActionResult Index()
        {

            return View(Repository.AllProducts);
        }



        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Create(Product product)
        {
            Repository.Create(product);
            return View("Success", product);
        }





        [HttpPost]

        public IActionResult Delete(string pname)
        {
            Product product = Repository.AllProducts.Where(p =>p.name == pname).FirstOrDefault();
            Repository.Delete(product);
            return RedirectToAction("Index");

        }

        public IActionResult Update(int pid)
        {
            Product product = Repository.AllProducts.Where(p => p.id == pid).FirstOrDefault();
            return View(product);
        }


        [HttpPost]

        public IActionResult Update(Product product, int pid)
        {
            Repository.AllProducts.Where(p => p.id == pid).FirstOrDefault().name = product.name;
            Repository.AllProducts.Where(p => p.id == pid).FirstOrDefault().Price = product.Price;
            return RedirectToAction("Index");
        }














    }




}

