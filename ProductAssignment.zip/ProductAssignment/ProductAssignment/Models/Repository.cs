﻿namespace ProductAssignment.Models
{
    public class Repository
    {
        private static List<Product> allProducts = new List<Product>();

        public static IEnumerable<Product> AllProducts
        {
            get { return allProducts; }
        }

        public static void Create(Product product)
        {
            allProducts.Add(product);

        }

        public static void Delete(Product product)
        {
            allProducts.Remove(product);
        }
    }
}
