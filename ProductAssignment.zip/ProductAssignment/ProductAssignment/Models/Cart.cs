﻿namespace ProductAssignment.Models
{
    public class Cart
    {
        private List<Product> products;

        public Cart()
        {
            products = new List<Product>();
        }

        public void AddProduct(Product product)
        {
            products.Add(product);
        }

      
        public Product GetProductById(int productId)
        {
            return products.FirstOrDefault(p => p.id == productId);
        }
    }
}
