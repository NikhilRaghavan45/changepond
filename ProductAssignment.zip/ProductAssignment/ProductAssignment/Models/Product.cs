﻿namespace ProductAssignment.Models
{
    public class Product
    {
        public int id { get; set; }
        public string name { get; set; }
        public decimal Price { get; set; }
        public double quantity { get; set; }
    }
}
