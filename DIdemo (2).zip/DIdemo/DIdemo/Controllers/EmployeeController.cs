﻿using Microsoft.AspNetCore.Mvc;
using DIdemo.Models;
using Microsoft.AspNetCore.Http;



namespace DIdemo.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Index(int id,string name) {
            string welcomeMessage=$"Welcome Employee:{name} with id :{id}";
            return View((object)welcomeMessage);
        }

      

        public IActionResult SessionData()
        {
            Employee employee = new Employee();
            employee.Id = 1;
            employee.Name = "Nikhil";
            employee.Designation = "Developer";

            // Use the generic Set<T> method for storing complex types
            HttpContext.Session.set<Employee>("employeedetails", employee);

            HttpContext.Session.SetString("Month", "December");
            HttpContext.Session.SetInt32("Days", 31);
            HttpContext.Session.SetString("Message", "Merry Christmas!!");

            return View();
        }

        public IActionResult ViewBagExample()
        {
            ViewBag.CurrentDateTime=DateTime.Now;
            ViewBag.CurrentYear=DateTime.Now.Year;
            ViewBag.Message = "Time is Ticking for the year";
            TempData["CurrentMonth"] = DateTime.Now.Month;
            TempData["Festival"] = "Christmas";
            return RedirectToAction("TempDataShow");
        }

        public IActionResult TempDataShow()
        {
            return View();
        }

        public IActionResult Details()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Detail(int id,string name)
        {
            Employee emp = new Employee();
            emp.Id= id;
            emp.Name= name;
            emp.Designation = "Manager";
            return View(emp);

        }
    }
}
