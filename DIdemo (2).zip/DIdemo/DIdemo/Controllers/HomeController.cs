﻿using DIdemo.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DIdemo.Controllers
{
    public class HomeController : Controller
    {
        private IRepository repository;

        private readonly ILogger<HomeController> _logger;


        public HomeController(IRepository repo, ILogger<HomeController> logger)
        {
            repository = repo;
            this._logger = logger;
        }

        public IActionResult Index()
        {
            return View(new Repository().Products);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}