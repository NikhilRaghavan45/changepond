﻿using MarkAttendance.Models;
using System.Security.Cryptography;
using System.Xml.Linq;

namespace MarkAttendance.Models
{
    public class Attendances
    {
        public int Att_id { get; set; }

        public int SId {  get; set; }

        public string SName { get; set; } 

        public DateTime Date { get; set; }

        public string CName { get;set; }

        public Char Attendance { get; set; }
    }
}

