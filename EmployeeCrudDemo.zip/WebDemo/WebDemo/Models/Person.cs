﻿namespace WebDemo.Models
{
    public class Person
    {
        public string Name { get; set; } = string.Empty;

        public int Age { get; set; } = 0;    

        public string location { get ; set; }=string.Empty;

    }
}
