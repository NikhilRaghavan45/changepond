﻿using Microsoft.AspNetCore.Mvc;
using WebDemo.Models;

namespace WebDemo.Controllers
{
    public class FirstController : Controller
    {
        public string Index()
        {
            return "Hello World";
        }

        public IActionResult Hello()
        {
            return View();
        }

        public IActionResult Message()
        {
            ViewBag.message = "Good Morning Friends";
            return View();
        }

        public IActionResult Info()
        {
            Person person=new Person();
            person.Name = "Nikhil";
            person.Age = 23;
            person.location = "Chennai";
            return View(person);
        }
    }
}

