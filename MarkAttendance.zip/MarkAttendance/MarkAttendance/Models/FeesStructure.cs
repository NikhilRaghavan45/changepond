﻿using System.ComponentModel.DataAnnotations;

namespace MarkAttendance.Models
{
    public class FeesStructure
    {
        
        public int Regid { get; set; }

        
        public string SName { get; set; }

        public int CId { get; set; }

        
        public string CName { get; set; }

        public long TCFees { get; set; }

       
        public string POption { get; set; }

      
        public int ICount { get; set; }

        public long APay { get; set; }

       
        public long PAmount { get; set; }

     
        public string PType { get; set; }
    }
}
