﻿namespace ApiController.Models
{
    public interface IRepository
    {
        IEnumerable<Reservations> Reservation { get; }
        Reservations this[int id] { get; }

        Reservations AddReservation(Reservations reservation);


        Reservations UpdateReservation(Reservations reservation);

        void DeleteReservation(int id);
    }
}
