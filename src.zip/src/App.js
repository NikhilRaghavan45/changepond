import logo from './logo.svg';
import './App.css';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import NavComp from './Component/NavComp';
import FooterComp from './Component/FooterComp';
import CourseComp from './Component/CourseComp';
import BodyComp from './Component/BodyComp';

function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header> */}
       <NavComp/>
       <CourseComp/>
      <FooterComp/>
      
    </div>
  );
}

export default App;
