﻿using AdoFirst.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace ADO.Controllers
{
    public class HomeController : Controller
    {
        public IConfiguration Configuration { get; }

        public HomeController(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = $"Delete from [Table] where Id = {id}";
                SqlCommand cmd = new SqlCommand(sql, connection);
                connection.Open();
                cmd.ExecuteNonQuery();
                connection.Close();
            }
            return RedirectToAction("Index");
        }

        public IActionResult ViewList()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Update(Table inventory, int id)
        {
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = "UpdateInventory";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    SqlParameter parameter = new SqlParameter
                    {
                        ParameterName = "@Id",
                        Value = id,
                        SqlDbType = SqlDbType.Int
                    };
                    command.Parameters.Add(parameter);

                    parameter = new SqlParameter
                    {
                        ParameterName = "@Name",
                        Value = inventory.Name,
                        SqlDbType = SqlDbType.VarChar,
                        Size = 50
                    };
                    command.Parameters.Add(parameter);

                    parameter = new SqlParameter
                    {
                        ParameterName = "@Price",
                        Value = inventory.Price,
                        SqlDbType = SqlDbType.Money
                    };
                    command.Parameters.Add(parameter);

                    parameter = new SqlParameter
                    {
                        ParameterName = "@Quantity",
                        Value = inventory.Quantity,
                        SqlDbType = SqlDbType.Int
                    };
                    command.Parameters.Add(parameter);

                    parameter = new SqlParameter
                    {
                        ParameterName = "@Result",
                        SqlDbType = SqlDbType.VarChar,
                        Size = 50,
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(parameter);

                    connection.Open();
                    command.ExecuteNonQuery();
                    string result = Convert.ToString(command.Parameters["@Result"].Value);

                    ViewBag.Result = result;
                    connection.Close();
                }
            }

            return RedirectToAction("Index");
        }


        public IActionResult Update(int Id)
        {
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            Table inventory = new Table();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string sql = $"select * from [Table] where Id='{Id}'";
                SqlCommand cmd = new SqlCommand(sql, connection);
                connection.Open();
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        inventory.Id = Convert.ToInt32(reader["Id"]);
                        inventory.Name = Convert.ToString(reader["Name"]);
                        inventory.Price = Convert.ToDecimal(reader["Price"]);
                        inventory.Quantity = Convert.ToInt32(reader["Quantity"]);
                        inventory.AddedOn = Convert.ToDateTime(reader["Addedon"]);
                    }
                }
                connection.Close();
            }
            return View(inventory);
        }
        public IActionResult Index()
        {

            List<Table> inventoryList = new List<Table>();

            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {


                //string sql = "select * from inventory";
                string sql = "ReadInventory";
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
                if (dataAdapter is not null)
                {
                    dataAdapter.Fill(dataTable);
                    foreach (DataRow dr in dataTable.Rows)
                    {
                        Table inventory = new Table();

                        inventory.Id = Convert.ToInt32(dr["Id"]);
                        inventory.Name = Convert.ToString(dr["Name"]);
                        inventory.Price = Convert.ToDecimal(dr["Price"]);
                        inventory.Quantity = Convert.ToInt32(dr["Quantity"]);
                        inventory.AddedOn = Convert.ToDateTime(dr["Addedon"]);
                        inventoryList.Add(inventory);
                    }
                }

            }


            /*   SqlConnection connection = new SqlConnection(connectionString);


               string sql = "select * from inventory";
               SqlCommand cmd = new SqlCommand(sql, connection);

               connection.Open();

               using (SqlDataReader reader = cmd.ExecuteReader()) {

                   while (reader.Read())
                   {
                       Inventory inventory = new Inventory();

                       inventory.Id = Convert.ToInt32(reader["Id"]);
                       inventory.Name = Convert.ToString(reader["Name"]);
                       inventory.Price = Convert.ToDecimal(reader["Price"]);
                       inventory.Quantity = Convert.ToInt32(reader["Quantity"]);
                       inventory.AddedOn = Convert.ToDateTime(reader["Addedon"]);
                       inventoryList.Add(inventory);
                       //for(int i=0;i<reader.FieldCount;i++)
                       //{
                       //    string currentColName = reader.GetName(i);
                       //    string currentColValue = Convert.ToString(reader.GetValue(i));
                       //}
                   }
               }
               connection.Close(); 
   */

            return View(inventoryList);
        }


        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Table inventory)
        {
            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // string sql = $"Insert into inventory(Name, Price,Quantity) Values ('{inventory.Name}', {inventory.Price}, {inventory.Quantity})";
                //    string sql = $"Insert into inventory(Name, Price,Quantity) Values (@Name,@Price, @Quantity)";
                string sql = "CreateInventory";
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                    //   command.CommandType = CommandType.Text;
                    command.CommandType = CommandType.StoredProcedure;
                    SqlParameter parameter = new SqlParameter
                    {
                        ParameterName = "@Name",
                        Value = inventory.Name,
                        SqlDbType = SqlDbType.VarChar,
                        Size = 50
                    };
                    command.Parameters.Add(parameter);
                    parameter = new SqlParameter
                    {
                        ParameterName = "@Price",
                        Value = inventory.Price,
                        SqlDbType = SqlDbType.Money
                    };
                    command.Parameters.Add(parameter);

                    parameter = new SqlParameter
                    {
                        ParameterName = "@Quantity",
                        Value = inventory.Quantity,
                        SqlDbType = SqlDbType.Int
                    };
                    command.Parameters.Add(parameter);

                    parameter = new SqlParameter
                    {
                        ParameterName = "@Result",
                        //Value = inventory.Quantity,
                        SqlDbType = SqlDbType.VarChar,
                        Size = 50,
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(parameter);

                    connection.Open();
                    command.ExecuteNonQuery();
                    string result = Convert.ToString(command.Parameters["@Result"].Value);


                    ViewBag.Result = result;
                    connection.Close();

                }
            }
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}