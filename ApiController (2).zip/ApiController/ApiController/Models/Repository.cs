﻿namespace ApiController.Models
{
    public class Repository: IRepository
    {
        private Dictionary<int, Reservations> items;
        public Repository() {
            items = new Dictionary<int, Reservations>();
            new List<Reservations> {
                new Reservations{ Id = 1, Name="Vignesh" , StartLocation="Chennai",EndLocation="Mumbai"},
                new Reservations{ Id = 2, Name="Mutthu" , StartLocation="Trivendrum",EndLocation="Chennai"},
                new Reservations{ Id = 3, Name="Santosh" , StartLocation="Pondhicherry",EndLocation="Banglore"},
                new Reservations{ Id = 4, Name="Gyan" , StartLocation="Mumbai",EndLocation="Chennai"}
            }.ForEach(r => AddReservation(r));
        }
        
        public Reservations this[int id] => items.ContainsKey(id) ? items[id] : null;

        public IEnumerable<Reservations> Reservation => items.Values;

        public void DeleteReservation(int id) => items.Remove(id);
        public Reservations UpdateReservation(Reservations reservation)=>AddReservation(reservation);
        public Reservations AddReservation(Reservations reservations)
        {
            if (reservations.Id == 0)
            {
                int key = items.Count;
                while(items.ContainsKey(key)) { key++; };
                reservations.Id = key;
            }
            items[reservations.Id] = reservations;
            return reservations;
        }
    }
}
