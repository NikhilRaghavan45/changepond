﻿namespace MarkAttendance.Models
{
    public class Attendances
    {
        public int Att_id { get; set; }

        public int SId {  get; set; }

        public string SName { get; set; } 

        public DateTime Date { get; set; }

        public Char Attendance { get; set; }
    }
}
