﻿namespace MarkAttendance.Models
{
    public class Module
    {
        public int MId { get; set; }
        public string MName { get; set; }
        public int CId { get; set; }
    }
}
